﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace LocationVoitures.Data.Models
{
    [Table("alertes")]
    public class Alerte
    {
        [Column("id")]
        public int Id { get; set; }

        [Column("type_alerte")]
        public string TypeAlerte { get; set; }

        [Column("message")]
        public string Message { get; set; }

        [Column("statut")]
        public string Statut { get; set; }

        [Column("voiture_id")]
        public int VoitureId { get; set; }

        [ForeignKey("VoitureId")]
        public virtual Voiture Voiture { get; set; }
    }
}
