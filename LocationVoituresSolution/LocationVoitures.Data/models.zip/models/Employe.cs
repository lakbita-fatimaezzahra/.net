﻿using System.ComponentModel.DataAnnotations.Schema;

namespace LocationVoitures.Data.Models
{
    [Table("employes")]
    public class Employe : Utilisateur
    {
        [Column("poste")]
        public string Poste { get; set; }

        [Column("salaire")]
        public double Salaire { get; set; }
    }
}
