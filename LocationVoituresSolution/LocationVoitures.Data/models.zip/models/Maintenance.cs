﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace LocationVoitures.Data.Models
{
    [Table("maintenances")]
    public class Maintenance
    {
        [Column("id")]
        public int Id { get; set; }

        [Column("date_maintenance")]
        public DateTime DateMaintenance { get; set; }

        [Column("cout")]
        public double Cout { get; set; }

        [Column("description")]
        public string Description { get; set; }

        [Column("voiture_id")]
        public int VoitureId { get; set; }

        [ForeignKey("VoitureId")]
        public virtual Voiture Voiture { get; set; }
    }
}
